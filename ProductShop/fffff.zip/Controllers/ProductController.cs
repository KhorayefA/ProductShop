﻿using System;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Mvc;
using ProductShop.Data;


namespace ProductShop.Controllers
{
    public class ProductController : ApiController
    {
        private IProductRepository _repository;

        public ProductController()
        {
            _repository = new ProductRepository();
        }
        //public IHttpActionResult Put()
        //{
        //    return BadRequest("No thing bad baby");
        //}

        public void POST(Product product)
        {
            _repository.AddProduct(product);
            _repository.SaveChangesAsync();
        }

        public async Task<IHttpActionResult> Get()
        {
            try
            {
                var result = await _repository.GetAllProductsAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        
        public async Task<IHttpActionResult> Delete(int productId)
        {
            try
            {
                var product = await _repository.GetProductAsync(productId);
                if (product == null) return NotFound();

                _repository.DeleteProduct(product);

                if(await _repository.SaveChangesAsync())
                {
                    return Ok();
                }
                else
                {
                    return InternalServerError();
                }
            }
            catch (Exception ex)
            {

                return InternalServerError(ex);
            }
        }



        //public object Get()
        //{

        //    return new { Name = "AbuYahya", Age = "25" };
        //}

        //public IHttpActionResult Get()
        //{
        //    return BadRequest("No thing bad baby");
        //    //return Ok(new { Name = "AbuYahya", Age = "25" });
        //}

        ////GET: Product
        //public string Index()
        //{
        //    return "test";
        //}

        //private IProductRepository _repository;

        //public ProductController(IProductRepository repository)
        //{
        //    _repository = repository;

        //}
        //public async Task<IHttpActionResult> Get()
        //{
        //    try
        //    {
        //        var result = await _repository.GetAllCampsAsync();

        //        //Mapping
        //        var mappedResult = _mapper.Map<IEnumerable<CampModel>>(result);

        //        return Ok(mappedResult);
        //    }
        //    catch
        //    {
        //        return InternalServerError();
        //    }
        //}
        //[Route("{id}")]
        //public async Task<IHttpActionResult> Get(int id)
        //{
        //    try
        //    {
        //        var result = await _repository.GetCampAsync(id);

        //        return Ok(result);
        //    }
        //    catch
        //    {
        //        return InternalServerError();
        //    }
        //}
    }
}

